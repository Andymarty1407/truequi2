package com.example.myapplication

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.myapplication.model.Producto
import com.google.firebase.database.FirebaseDatabase

class EditarProductoActivity : AppCompatActivity() {

    private lateinit var etTitulo: EditText
    private lateinit var etDescripcion: EditText
    private lateinit var etEstado: EditText
    private lateinit var etCategoria: EditText
    private lateinit var btnGuardarCambios: Button

    private lateinit var img1: ImageView
    private lateinit var img2: ImageView
    private lateinit var img3: ImageView
    private lateinit var img4: ImageView

    private var imagenes: List<String> = emptyList()
    private var productoId: String = ""
    private var creadorUID: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_producto)

        etTitulo = findViewById(R.id.etTitulo)
        etDescripcion = findViewById(R.id.etDescripcion)
        etEstado = findViewById(R.id.etEstado)
        etCategoria = findViewById(R.id.etCategoria)
        btnGuardarCambios = findViewById(R.id.btnGuardarCambios)

        img1 = findViewById(R.id.imgEditar1)
        img2 = findViewById(R.id.imgEditar2)
        img3 = findViewById(R.id.imgEditar3)
        img4 = findViewById(R.id.imgEditar4)

        val producto = intent.getSerializableExtra("producto") as? Producto

        if (producto != null) {
            etTitulo.setText(producto.titulo)
            etDescripcion.setText(producto.descripcion)
            etEstado.setText(producto.estado)
            etCategoria.setText(producto.categoria)

            imagenes = producto.imagenes
            productoId = producto.id
            creadorUID = producto.creadorUID

            // Mostrar las imágenes si existen
            if (imagenes.isNotEmpty()) {
                val imageViews = listOf(img1, img2, img3, img4)
                for (i in imagenes.indices) {
                    if (i < imageViews.size) {
                        Glide.with(this).load(imagenes[i]).into(imageViews[i])
                    }
                }
            }

            btnGuardarCambios.setOnClickListener {
                val nuevoTitulo = etTitulo.text.toString().trim()
                val nuevaDescripcion = etDescripcion.text.toString().trim()
                val nuevoEstado = etEstado.text.toString().trim()
                val nuevaCategoria = etCategoria.text.toString().trim()

                if (nuevoTitulo.isEmpty() || nuevaDescripcion.isEmpty() || nuevoEstado.isEmpty() || nuevaCategoria.isEmpty()) {
                    Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val ref = FirebaseDatabase.getInstance()
                    .getReference("productos")
                    .child(creadorUID) // 🔧 CORREGIDO
                    .child(productoId)

                val cambios = mapOf(
                    "titulo" to nuevoTitulo,
                    "descripcion" to nuevaDescripcion,
                    "estado" to nuevoEstado,
                    "categoria" to nuevaCategoria
                )

                Log.d("EditarProducto", "Actualizando $productoId de $creadorUID con $cambios")

                ref.updateChildren(cambios)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Producto actualizado correctamente", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Error al actualizar producto", Toast.LENGTH_SHORT).show()
                    }
            }
        } else {
            Toast.makeText(this, "No se pudo cargar el producto", Toast.LENGTH_LONG).show()
            finish()
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
