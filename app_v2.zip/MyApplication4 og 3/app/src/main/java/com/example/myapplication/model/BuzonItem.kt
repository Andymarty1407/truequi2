package com.example.myapplication.model

data class BuzonItem(
    val titulo: String = "",
    val categoria: String = "",
    val nombre: String = "",
    val chatId: String = "",
)






